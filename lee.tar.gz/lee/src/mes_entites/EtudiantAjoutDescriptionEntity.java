package mes_entites;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "ETUDIANT_AJOUT_DESCRIPTION", schema = "LEE", catalog = "")
@IdClass(EtudiantAjoutDescriptionEntityPK.class)
public class EtudiantAjoutDescriptionEntity {
    private int idEtudiant;
    private int idCour;
    private String description;

    @Id
    @Column(name = "ID_ETUDIANT", nullable = false, precision = 0)
    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    @Id
    @Column(name = "id-cour", nullable = false, precision = 0)
    public int getIdCour() {
        return idCour;
    }

    public void setIdCour(int idCour) {
        this.idCour = idCour;
    }

    @Basic
    @Column(name = "DESCRIPTION", nullable = true, length = 50)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EtudiantAjoutDescriptionEntity that = (EtudiantAjoutDescriptionEntity) o;
        return idEtudiant == that.idEtudiant &&
                idCour == that.idCour &&
                Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEtudiant, idCour, description);
    }
}
