package mes_entites;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "COUR", schema = "LEE", catalog = "")
public class CourEntity {
    private int id;
    private String nom;
    private String ensiegnant;

    @Id
    @Column(name = "ID", nullable = false, precision = 0)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "NOM", nullable = true, length = 30)
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Basic
    @Column(name = "ENSIEGNANT", nullable = true, length = 20)
    public String getEnsiegnant() {
        return ensiegnant;
    }

    public void setEnsiegnant(String ensiegnant) {
        this.ensiegnant = ensiegnant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourEntity that = (CourEntity) o;
        return id == that.id &&
                Objects.equals(nom, that.nom) &&
                Objects.equals(ensiegnant, that.ensiegnant);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nom, ensiegnant);
    }



}
