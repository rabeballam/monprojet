package mes_entites;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "ENSEIGNANT_AJOUT_DESCRIPTION", schema = "LEE", catalog = "")
public class EnseignantAjoutDescriptionEntity {
    private int idCours;
    private String description;
    private String idProf;

    @Basic
    @Column(name = "id-cours", nullable = false, precision = 0)
    public int getIdCours() {
        return idCours;
    }

    public void setIdCours(int idCours) {
        this.idCours = idCours;
    }

    @Basic
    @Column(name = "DESCRIPTION", nullable = true, length = 50)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "ID_PROF", nullable = true, length = 20)
    public String getIdProf() {
        return idProf;
    }

    public void setIdProf(String idProf) {
        this.idProf = idProf;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EnseignantAjoutDescriptionEntity that = (EnseignantAjoutDescriptionEntity) o;
        return idCours == that.idCours &&
                Objects.equals(description, that.description) &&
                Objects.equals(idProf, that.idProf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCours, description, idProf);
    }
}
