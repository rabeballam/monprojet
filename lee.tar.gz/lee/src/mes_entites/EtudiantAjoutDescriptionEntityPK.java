package mes_entites;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class EtudiantAjoutDescriptionEntityPK implements Serializable {
    private int idEtudiant;
    private int idCour;

    @Column(name = "ID_ETUDIANT", nullable = false, precision = 0)
    @Id
    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    @Column(name = "id-cour", nullable = false, precision = 0)
    @Id
    public int getIdCour() {
        return idCour;
    }

    public void setIdCour(int idCour) {
        this.idCour = idCour;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EtudiantAjoutDescriptionEntityPK that = (EtudiantAjoutDescriptionEntityPK) o;
        return idEtudiant == that.idEtudiant &&
                idCour == that.idCour;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEtudiant, idCour);
    }


}
